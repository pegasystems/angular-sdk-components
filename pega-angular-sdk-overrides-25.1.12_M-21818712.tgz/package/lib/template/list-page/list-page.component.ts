import { Component, Input, forwardRef } from '@angular/core';
import { ComponentMapperComponent } from '@pega/angular-sdk-components';

@Component({
  selector: 'app-list-page',
  templateUrl: './list-page.component.html',
  styleUrls: ['./list-page.component.scss'],
  imports: [forwardRef(() => ComponentMapperComponent)]
})
export class ListPageComponent {
  @Input() pConn$: typeof PConnect;
}
